function [C]=tank_capacitance(A,rho,g)

C    =   A/rho/g;